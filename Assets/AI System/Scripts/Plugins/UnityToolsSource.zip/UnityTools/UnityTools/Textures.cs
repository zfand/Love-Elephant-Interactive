﻿using UnityEngine;

namespace UnityTools
{
    public static class Textures
    {

        private static Texture2D seperatorArrorws;
        public static Texture2D SeperatorArrows
        {
            get{
                if (!seperatorArrorws){
                    seperatorArrorws = LoadDllResource("SeperatorArrows.png", 89, 40);
                }
                return seperatorArrorws;
            }
        }

        private static Texture2D minus;
        public static Texture2D Minus
        {
            get{
                if (!minus){
                    minus = LoadDllResource("Minus.png", 90, 90);

                }
                return minus;
            }
        }

        private static Texture2D plus;
        public static Texture2D Plus
        {
            get {
                if (!plus){
                    plus = LoadDllResource("Plus.png", 90, 90);
                }
                return plus;
            }
        }

        private static Texture2D search;
        public static Texture2D Search{
            get{
                if (!search)
                {
                    search = LoadDllResource("Search.png", 26, 26);
                }
                return search;
            }
        }


        private static System.Collections.Generic.List<Texture2D> textures= new System.Collections.Generic.List<Texture2D>();
        public static void UnloadTextures() {
            foreach (Texture2D texture in textures) {
                Object.DestroyImmediate(texture);
            }
        }

        public static Texture2D LoadDllResource(string resourceName, int width, int height){
            // first try to load as local resource, in case not running dll version
            // also lets you override dll resources locally for rapid iteration
            Texture2D texture = (Texture2D)Resources.Load(resourceName);
            if (texture != null)
            {
                Debug.Log("Loaded local resource: " + resourceName);
                return texture;
            }
            // if unavailable, try assembly
            System.Reflection.Assembly myAssembly = System.Reflection.Assembly.GetExecutingAssembly();
            System.IO.Stream myStream = myAssembly.GetManifestResourceStream("UnityTools.Resources." + resourceName);
            texture = new Texture2D(width, height, TextureFormat.ARGB32, false);
            texture.LoadImage(ReadToEnd(myStream));

            if (texture == null)
            {
                Debug.LogError("Missing Dll resource: " + resourceName);
            }

            if (textures == null){
                textures = new System.Collections.Generic.List<Texture2D>();
            }
            textures.Add(texture);
            return texture;
        }

        static byte[] ReadToEnd(System.IO.Stream stream){
            long originalPosition = stream.Position;
            stream.Position = 0;
            try
            {
                byte[] readBuffer = new byte[4096];
                int totalBytesRead = 0;
                int bytesRead;
                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;
                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            System.Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            System.Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    System.Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                stream.Position = originalPosition;
            }
        }

    }
}
