﻿using UnityEngine;

namespace UnityTools.Math
{
    public static class Math
    {
        /// <summary>
        /// Compares the square magniture of target - second to given float value
        /// </summary>
        public static bool AlmostEquals(this Vector3 target, Vector3 second, float sqrMagniturePrecision)
        {
            return (target - second).sqrMagnitude < sqrMagniturePrecision;
        }

        /// <summary>
        /// Compares the square magniture of target - second to given float value
        /// </summary>
        public static bool AlmostEquals(this Vector2 target, Vector2 second, float sqrMagniturePrecision)
        {
            return (target - second).sqrMagnitude < sqrMagniturePrecision;
        }

        /// <summary>
        /// Compares the angle between target and second to given float value
        /// </summary>
        public static bool AlmostEquals(this Quaternion target, Quaternion second, float maxAngle)
        {
            return Quaternion.Angle(target, second) < maxAngle;
        }

        /// <summary>
        /// Compares two floats and returns true of their difference is less than floatDiff
        /// </summary>
        public static bool AlmostEquals(this float target, float second, float floatDiff)
        {
            return Mathf.Abs(target - second) < floatDiff;
        }
    }
}
