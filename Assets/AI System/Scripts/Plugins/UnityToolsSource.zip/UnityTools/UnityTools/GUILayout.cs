﻿using UnityEngine;

namespace UnityTools
{
    public static class GUILayout
    {
        /// <summary>
        /// Custom button to display a texture with transparent areas.
        /// </summary>
        public static bool Button(Texture2D texture, params GUILayoutOption[] options)
        {
            return Button(texture,"",GUI.skin.label.fontSize,GUI.skin.label.fontStyle, options);
        }

        /// <summary>
        /// Custom button to display a texture with transparent areas.
        /// </summary>
        public static bool Button(Texture2D texture,string label, params GUILayoutOption[] options)
        {
            return Button(texture, label, GUI.skin.label.fontSize, GUI.skin.label.fontStyle, options);
        }

        /// <summary>
        /// Custom button to display a texture with transparent areas and label on the right side.
        /// </summary>
        public static bool Button(Texture2D texture,string label, int fontSize, params GUILayoutOption[] options)
        {
            return Button(texture,label, fontSize, GUI.skin.label.fontStyle, options);
        }

        private static bool clicked = false;
        /// <summary>
        /// Custom button to display a texture with transparent areas and text on the right side.
        /// </summary>
        public static bool Button(Texture2D texture, string label,int fontSize,FontStyle fontStyle, params GUILayoutOption[] options)
        {
            if (!string.IsNullOrEmpty(label)){
                UnityEngine.GUILayout.BeginHorizontal();
            }
            GUIContent content = new GUIContent(texture);
            Rect rect = GUILayoutUtility.GetRect(content, "label", options);
            if (CheckRect(Event.current.mousePosition, rect) && GUI.enabled)
            {
                rect = new Rect(rect.x - 1, rect.y - 1, rect.width + 2, rect.height + 2);
                switch (Event.current.type) {
                    case EventType.MouseDown:
                        clicked = true;
                        break;
                    case EventType.MouseUp:
                        clicked = false;
                        break;
                }
            }
            GUI.color = clicked ? Color.gray : Color.white;
            bool result = false;
           
            if (GUI.Button(rect, content, "label")){
                result = true;
            }
            
            if (!string.IsNullOrEmpty(label)) {
                Label(label, fontSize, fontStyle);
                UnityEngine.GUILayout.EndHorizontal();
            }
            return result;
        }

        private static bool CheckRect(Vector2 point, Rect rect){
            return point.x >= rect.x && point.x <= rect.x + rect.width &&
                    point.y >= rect.y && point.y <= rect.y + rect.height;
        }

        /// <summary>
        /// Draw label with given fontSize.
        /// </summary>
        public static void Label(string text, int fontSize)
        {
            Label(text, fontSize, UnityEngine.GUI.skin.label.fontStyle);
        }

        /// <summary>
        /// Draw label with given fontSize and fontStyle.
        /// </summary>
        public static void Label(string text, int fontSize, FontStyle fontStyle)
        {
            int backUpSize = UnityEngine.GUI.skin.label.fontSize;
            FontStyle backUpFontStyle = UnityEngine.GUI.skin.label.fontStyle;

            UnityEngine.GUI.skin.label.fontSize = fontSize;
            UnityEngine.GUI.skin.label.fontStyle = fontStyle;
            UnityEngine.GUILayout.Label(text);
            UnityEngine.GUI.skin.label.fontSize = backUpSize;
            UnityEngine.GUI.skin.label.fontStyle = backUpFontStyle;
        }

        /// <summary>
        /// Draw a seperator line.
        /// </summary>
        public static void Seperator()
        {
            UnityEngine.GUILayout.Box("", new GUILayoutOption[] { UnityEngine.GUILayout.ExpandWidth(true), UnityEngine.GUILayout.Height(1) });
        }

    }
}
